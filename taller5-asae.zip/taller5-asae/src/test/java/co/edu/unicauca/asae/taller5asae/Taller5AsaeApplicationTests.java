package co.edu.unicauca.asae.taller5asae;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Taller5AsaeApplicationTests {

	@Test
	void contextLoads() {
	}

}
