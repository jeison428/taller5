package co.edu.unicauca.asae.taller5asae;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Taller5AsaeApplication {

	public static void main(String[] args) {
		SpringApplication.run(Taller5AsaeApplication.class, args);
	}

}
