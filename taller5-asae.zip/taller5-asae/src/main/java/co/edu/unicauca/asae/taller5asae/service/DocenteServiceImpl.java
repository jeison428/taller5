package co.edu.unicauca.asae.taller5asae.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import co.edu.unicauca.asae.taller5asae.entity.Docente;
import co.edu.unicauca.asae.taller5asae.repository.DocenteRepository;

@Service
public class DocenteServiceImpl implements DocenteService {
    
    @Autowired
    private DocenteRepository docenteRepo;

    @Override
    public ResponseEntity<?> findAllPatronBusqueda(String identificacion, String nombres, String apellidos, String correo) {
        HashMap<String, Object> respuestas = new HashMap<>();
        ResponseEntity<?> respuesta = null;
        List<Docente> docentesDB = null;
        try {
            docentesDB = this.docenteRepo.findByIdentificacionIgnoreCaseContainingOrNombresIgnoreCaseContainingOrApellidosIgnoreCaseContainingOrCorreoIgnoreCaseContaining(identificacion, nombres, apellidos , correo);
            if (docentesDB.isEmpty()){
                respuestas.put("mensaje", "No se encontro ninguna coincidencia en la busqueda de Docentes.");
                respuesta = new ResponseEntity<HashMap<String, Object>>(respuestas, HttpStatus.NOT_FOUND);
            }else{
                respuesta = new ResponseEntity<List<Docente>>(docentesDB, HttpStatus.OK);
            }
        } catch (Exception e) {
            respuestas.put("mensaje", "Error al realizar la consulta en la base de datos");
            respuestas.put("descripción del error", e.getMessage());
            respuesta = new ResponseEntity<HashMap<String, Object>>(respuestas,HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return respuesta;
    }

    @Override
    public ResponseEntity<?> findAllBusquedaOrdenada(String nombres) {
        HashMap<String, Object> respuestas = new HashMap<>();
        ResponseEntity<?> respuesta = null;
        List<Docente> docentesDB = null;
        try {
            docentesDB = this.docenteRepo.findByNombresIgnoreCaseOrderByIdentificacionDesc(nombres);
            if (docentesDB.isEmpty()){
                respuestas.put("mensaje", "No se encontro ninguna coincidencia en la busqueda de Docentes.");
                respuesta = new ResponseEntity<HashMap<String, Object>>(respuestas, HttpStatus.NOT_FOUND);
            }else{
                respuesta = new ResponseEntity<List<Docente>>(docentesDB, HttpStatus.OK);
            }
        } catch (Exception e) {
            respuestas.put("mensaje", "Error al realizar la consulta en la base de datos");
            respuestas.put("descripción del error", e.getMessage());
            respuesta = new ResponseEntity<HashMap<String, Object>>(respuestas,HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return respuesta;
    }

    @Override
    public ResponseEntity<?> findAllGrupoInvAndVinculacion(String grupoInv, String vinculacion) {
        HashMap<String, Object> respuestas = new HashMap<>();
        ResponseEntity<?> respuesta = null;
        List<Docente> docentesDB = null;
        try {
            docentesDB = this.docenteRepo.findByGrupoInvAndTipoVinculacion(grupoInv, vinculacion);
            if (docentesDB.isEmpty()){
                respuestas.put("mensaje", "No se encontro ninguna coincidencia en la busqueda de Docentes.");
                respuesta = new ResponseEntity<HashMap<String, Object>>(respuestas, HttpStatus.NOT_FOUND);
            }else{
                respuesta = new ResponseEntity<List<Docente>>(docentesDB, HttpStatus.OK);
            }
        } catch (Exception e) {
            respuestas.put("mensaje", "Error al realizar la consulta en la base de datos");
            respuestas.put("descripción del error", e.getMessage());
            respuesta = new ResponseEntity<HashMap<String, Object>>(respuestas,HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return respuesta;
    }

}
