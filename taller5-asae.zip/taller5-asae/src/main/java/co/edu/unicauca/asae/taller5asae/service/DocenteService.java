package co.edu.unicauca.asae.taller5asae.service;

import org.springframework.http.ResponseEntity;

public interface DocenteService {

    public ResponseEntity<?> findAllPatronBusqueda(String identificacion, String nombres, String apellidos, String correo);
    public ResponseEntity<?> findAllBusquedaOrdenada(String nombres);
    public ResponseEntity<?> findAllGrupoInvAndVinculacion(String grupoInv, String vinculacion);
    
}
