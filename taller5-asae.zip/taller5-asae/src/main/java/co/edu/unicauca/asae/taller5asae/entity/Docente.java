package co.edu.unicauca.asae.taller5asae.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name="Docente")
@Data
public class Docente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	private String tipoIdentificacion;
	private String identificacion;
	private String nombres;	
	private String apellidos;
	private String telefono;
	private String correo;
	private String genero;
	private String titulo;
    private String universidadTitulo;
    private String categoriaMic;
    private String linkCvLac;
    private String facultad;
    private String departamento;
    private String grupoInv;
    private String lineaInv;
    private String tipoVinculacion;
    private String escalafon;
    private String observacion;
    
}
